package sistema;

public class Bebidas extends Categoria {

    public static Object get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private int quantidade; // nova variável

    public Bebidas(String nome, double preco) {
        super(nome, preco);
        this.quantidade = 0; // inicializa com 0
    }

    public void incrementar() {
        this.quantidade++;
    }

    public void decrementar() {
        if (this.quantidade > 0) {
            this.quantidade--;
        }
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String getDescricaoCategoria() {
        return "Bebida: " + getNome();
    }

    @Override
    public String toString() {
        return getNome() + " - R$" + getPreco() + " | Qtd: " + quantidade;
    }
}
