package ModelArthur;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author arthu
 */
public class SistemaAvaliacoes {
    private static List<Avaliacao> avaliacoesDoDia = new ArrayList<>();

    public static void adicionarAvaliacao(Avaliacao avaliacao) {
        // Só adiciona se a avaliação for da data atual
        if (avaliacao.getData().equals(LocalDate.now())) {
            avaliacoesDoDia.add(avaliacao);
        }
    }

    public static List<Avaliacao> getAvaliacoesDoDia() {
        return avaliacoesDoDia;
    }

    public static void limparAvaliacoes() {
        avaliacoesDoDia.clear(); // se quiser "resetar" no fim do dia, manualmente
    }
}