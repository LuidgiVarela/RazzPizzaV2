package ModelArthur;
import java.time.LocalDate;
/**
 * @author arthu
 */
public class Avaliacao {

    // Texto 
    private String texto;

    // Data 
    private LocalDate data;

    // Atributo estático que armazena a última avaliação feita (em memória)
    private static Avaliacao avaliacaoSalvaGlobal;

    // Construtor que define o texto da avaliação e salva a data atual automaticamente
    public Avaliacao(String texto) {
        this.texto = texto;
        this.data = LocalDate.now(); // Define data automática no momento da avaliação
    }

    // Getter do texto 
    public String getTexto() {
        return texto;
    }

    // Getter da data 
    public LocalDate getData() {
        return data;
    }

    // Getter estático para acessar a avaliação salva globalmente
    public static Avaliacao getAvaliacaoSalvaGlobal() {
        return avaliacaoSalvaGlobal;
    }

    // Setter estático para definir uma avaliação global
    public static void setAvaliacaoSalvaGlobal(Avaliacao avaliacao) {
        avaliacaoSalvaGlobal = avaliacao;
    }

    // Representação textual da avaliação (para testes, logs, etc.)
    @Override
    public String toString() {
        return "[" + data + "] " + texto;
    }
}